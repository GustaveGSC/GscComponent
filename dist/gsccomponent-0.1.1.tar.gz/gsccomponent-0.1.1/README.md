# GscComponent
the component for GSC
